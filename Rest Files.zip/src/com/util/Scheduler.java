package com.util;

public class Scheduler implements Runnable{

	@Override
	public void run() {
		
		do{
		SeleniumUtil.initiateBatch();
		try {
			Thread.sleep(5000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}while(true);
	}

}
