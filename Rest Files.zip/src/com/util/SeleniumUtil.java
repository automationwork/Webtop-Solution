package com.util;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;

public class SeleniumUtil {
	
	public static WebDriver driver;
	public static int count;
	public static boolean is64bit = false;
	
	static{
		
		if (System.getProperty("os.name").contains("Windows")) {
		    is64bit = (System.getenv("ProgramFiles(x86)") != null);
		} else {
		    is64bit = (System.getProperty("os.arch").indexOf("64") != -1);
		}
		
		initiateIEBrowser(is64bit);
		count = 0;
	}
	
	public static void main(String[] args) {
		
		SeleniumUtil.initiateBatch();
		
	}

	public static WebDriver initiateIEBrowser(boolean osbit) {
		
		//DesiredCapabilities capabilities = DesiredCapabilities.internetExplorer();
		//capabilities.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
		//capabilities.setCapability(InternetExplorerDriver.IGNORE_ZOOM_SETTING, true);
		if(osbit)
		{
			System.setProperty("webdriver.ie.driver", "drivers/IEDriverServer64.exe");
		}
		else
		{
			System.setProperty("webdriver.ie.driver", "drivers/IEDriverServer32.exe");
		}
		 
		driver = new InternetExplorerDriver();
		driver.manage().window().maximize();
		//driver.get("https://elearn.welingkar.org/");
		driver.get("https://www.google.co.in");
		System.out.println(driver.getCurrentUrl());
		return driver;
		
	}
	
	public static WebDriver initiateChromeBrowser() {
		System.setProperty("webdriver.chrome.driver", "drivers/chromedriver.exe");
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("https://elearn.welingkar.org/");
		System.out.println(driver.getCurrentUrl());
		return driver;
		
	}

	public static void initiateBatch() {
		
		WebElement userElement = driver.findElement(By.name("username"));
		userElement.clear();
		userElement.sendKeys("nikhilk_careers@yahoo.in"+" ::: Call "+count++);
		
		System.out.println(userElement);
		
		
	}
}
	